"""List or unpack one original initial fixture. Never executes tests or model code."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parent

def load(path):
    return json.loads(path.read_text(encoding='utf-8'))

def unpack(set_id, entry_id, output):
    catalog = load(ROOT / 'catalog.json')
    suite = next((s for s in catalog['sets'] if s['set_id'] == set_id), None)
    if suite is None:
        raise ValueError('Unknown set ID')
    entry = next((e for e in suite['entries'] if e['entry_id'] == entry_id), None)
    if entry is None:
        raise ValueError('Unknown entry ID')
    destination = Path(output).resolve()
    if destination.exists():
        raise ValueError('Output already exists; choose a new directory to preserve prior work')
    source = ROOT / entry['path']
    fixture = load(source / 'fixture.json')
    payloads = []
    for name, digest in fixture.items():
        relative = PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts or ':' in name or '\\' in name:
            raise ValueError('Unsafe fixture path')
        data = (ROOT / 'objects' / (digest + '.txt')).read_bytes()
        if hashlib.sha256(data).hexdigest() != digest:
            raise ValueError('Corrupt source object: ' + digest)
        target = destination / 'workspace' / name
        if not target.resolve().is_relative_to(destination):
            raise ValueError('Path escapes output')
        payloads.append((target, data))
    destination.mkdir(parents=True)
    for target, data in payloads:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    for name in ['task.json', 'PROMPT.md']:
        (destination / name).write_bytes((source / name).read_bytes())
    # Keep evaluator material separate from the agent's workspace.
    evaluator = destination / 'evaluator'
    evaluator.mkdir()
    (evaluator / 'evaluation.json').write_bytes((source / 'evaluation.json').read_bytes())
    print(f'Wrote {len(fixture)} initial files to {destination / "workspace"}')
    print(f'Agent input: {destination / "PROMPT.md"}; evaluator: {evaluator}')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--list', action='store_true')
    parser.add_argument('--set')
    parser.add_argument('--task', help='Entry ID shown in the catalog (may differ from historical task_id)')
    parser.add_argument('--output')
    args = parser.parse_args()
    if args.list:
        for suite in load(ROOT / 'catalog.json')['sets']:
            print(suite['set_id'], suite['entry_count'])
        return
    if not all([args.set, args.task, args.output]):
        parser.error('--set, --task and --output are required')
    unpack(args.set, args.task, args.output)

if __name__ == '__main__':
    main()
