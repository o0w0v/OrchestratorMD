"""Deterministic benchmark validators (stdlib, fixed contracts, no self grading).

AST restrictions are defense in depth, NOT a hostile-code sandbox.
"""
import ast
import copy
import io
import json
import sys
import time
import traceback
import types
import unittest
from html.parser import HTMLParser
from pathlib import Path


def region(text, name):
    lines = text.splitlines(keepends=True)
    start = [i for i,s in enumerate(lines) if s.strip() in (f"# worker:begin {name}", f"<!-- worker:begin {name} -->")]
    end = [i for i,s in enumerate(lines) if s.strip() in (f"# worker:end {name}", f"<!-- worker:end {name} -->")]
    if len(start)!=1 or len(end)!=1 or start[0]>=end[0]:
        raise ValueError("invalid markers")
    return "".join(lines[:start[0]+1]), "".join(lines[start[0]+1:end[0]]), "".join(lines[end[0]:])


def replace(text, name, body):
    a,_,b=region(text,name)
    return a + body.rstrip("\r\n") + "\n" + b


def lint(files):
    errors=[]
    local={Path(p).stem for p in files if p.endswith(".py")}
    allowed=local|{"unittest","json","re","datetime","decimal","math","collections","html"}
    banned={"open","eval","exec","compile","getattr","setattr","delattr","globals","locals","vars","input","breakpoint","help","exit","quit"}
    for path,text in files.items():
        if not path.endswith(".py"):
            continue
        try:
            tree=ast.parse(text,filename=path)
            for node in ast.walk(tree):
                if isinstance(node,ast.Import):
                    if any(a.name.split(".")[0] not in allowed for a in node.names):
                        raise ValueError("import outside fixed stdlib/fixture allowlist")
                if isinstance(node,ast.ImportFrom) and (node.level or (node.module or "").split(".")[0] not in allowed):
                    raise ValueError("import outside fixed stdlib/fixture allowlist")
                if isinstance(node,ast.Name) and (node.id in banned or node.id.startswith("__") and node.id != "__name__"):
                    raise ValueError("disallowed runtime/introspection name "+node.id)
                if isinstance(node,ast.Attribute) and node.attr.startswith("__"):
                    raise ValueError("dunder introspection prohibited")
                if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.decorator_list:
                    raise ValueError("decorators/skip forbidden in benchmark fixtures")
            if "skipTest" in text or "unittest.skip" in text:
                raise ValueError("skips forbidden")
        except (SyntaxError,ValueError) as exc:
            errors.append(f"{path}: {exc}")
    return {"passed":not errors,"checker":"Python AST syntax + restricted fixture policy (not ruff)","errors":errors}


def module(name, text):
    mod=types.ModuleType(name)
    sys.modules[name]=mod
    exec(compile(text,name+".py","exec"), mod.__dict__)
    return mod


def suite(files, subject_text, test_path):
    module("subject",subject_text)
    mod=module("generated_tests",files[test_path])
    tests=unittest.defaultTestLoader.loadTestsFromModule(mod)
    buf=io.StringIO()
    result=unittest.TextTestRunner(stream=buf,verbosity=2).run(tests)
    return {"passed":result.wasSuccessful() and result.testsRun>0 and not result.skipped,
            "count":result.testsRun,"stdout":buf.getvalue(),"skipped":len(result.skipped)}


class HTML(HTMLParser):
    def __init__(self):
        super().__init__(); self.nodes=[]; self.stack=[]; self.errors=[]
    def handle_starttag(self,tag,attrs):
        node={"tag":tag,"attrs":dict(attrs),"text":""}; self.nodes.append(node)
        if tag not in {"input","br","hr","meta","link","img"}: self.stack.append(node)
        if tag in {"script","iframe","object"} or any(k.lower().startswith("on") for k,v in attrs): self.errors.append("active content")
    def handle_data(self,data):
        for node in self.stack: node["text"] += data
    def handle_endtag(self,tag):
        if not self.stack or self.stack[-1]["tag"]!=tag: self.errors.append("unbalanced closing tag: "+tag)
        else: self.stack.pop()


def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True)


def validate(task, files, answer=None):
    start=time.perf_counter()
    checks={"lint":lint(files),"test":{"passed":False,"count":0,"failures":[]},"typecheck":None}
    failures=checks["test"]["failures"]
    try:
        if not checks["lint"]["passed"]:
            failures.append("Execution blocked by syntax/static fixture policy")
        elif task["task_type"] in {"SPECIFICATION","ERROR_ANALYSIS"}:
            expected=task["expected_answer"]
            checks["test"]["count"]=len(expected)
            # Arrays for constraints are sets; cases remain ordered as requested.
            normalized=copy.deepcopy(answer)
            if isinstance(normalized,dict) and isinstance(normalized.get("constraints"),list):
                normalized["constraints"]=sorted(normalized["constraints"])
            target=copy.deepcopy(expected)
            if "constraints" in target: target["constraints"]=sorted(target["constraints"])
            if not isinstance(normalized,dict): failures.append("answer must be a JSON object")
            else:
                for key,value in target.items():
                    if canonical(normalized.get(key))!=canonical(value):
                        # Actual validator output, same for every model, returned directly on repair.
                        failures.append({"field":key,"expected":value,"actual":normalized.get(key)})
                if set(normalized)!=set(target): failures.append("answer fields differ from contract")
        elif task["task_type"]=="TEMPLATE_UI":
            parser=HTML(); parser.feed(files["template.html"]); parser.close()
            failures.extend(parser.errors)
            if parser.stack: failures.append("unclosed HTML tags")
            checks["test"]["count"]=len(task["acceptance_cases"])
            for expected in task["acceptance_cases"]:
                if not any(node["tag"]==expected["tag"] and all(k in node["attrs"] and node["attrs"][k]==v for k,v in expected.get("attrs",{}).items())
                           and ("text" not in expected or node["text"].strip()==expected["text"]) for node in parser.nodes):
                    failures.append({"missing_element":expected})
            for node in parser.nodes:
                for key in ("src","href"):
                    value=node["attrs"].get(key) or ""
                    if value and not value.startswith("?page="): failures.append("unexpected external/resource URL")
        elif task["task_type"]=="UNIT_TEST_GENERATION":
            base=suite(files,files["subject.py"],"test_subject.py")
            checks["test"]["generated_suite"]=base; checks["test"]["count"]=base["count"]
            if not base["passed"]: failures.append("generated suite fails on reference or has no tests")
            killed=[]
            for i,body in enumerate(task["mutants"]):
                mutant=replace(files["subject.py"],"body",body)
                result=suite(files,mutant,"test_subject.py")
                killed.append(not result["passed"] and result["count"]>0)
                if not killed[-1]: failures.append(f"mutant {i+1} survived (required behavioral regression not detected)")
            checks["test"]["mutants_killed"]=killed
        else:
            if task.get("navigation"):
                module("helpers",files["helpers.py"])
                obj=module("report",files["report.py"]); func=obj.report
            else:
                obj=module("subject",files["subject.py"])
                func=getattr(obj,task["interface"].split("(")[0].split()[-1])
            for i,c in enumerate(task["acceptance_cases"]):
                checks["test"]["count"] += 1
                args=copy.deepcopy(c["args"]); before=copy.deepcopy(args)
                try:
                    actual=func(*args)
                    if "raises" in c: failures.append({"case":i,"expected_exception":c["raises"],"actual":actual})
                    elif canonical(actual)!=canonical(c["expected"]): failures.append({"case":i,"expected":c["expected"],"actual":actual})
                except Exception as exc:
                    if type(exc).__name__ != c.get("raises"): failures.append({"case":i,"exception":type(exc).__name__,"message":str(exc)})
                if args!=before: failures.append({"case":i,"reason":"input mutated"})
            if task["task_type"]=="DEBUGGING":
                reg=suite(files,files["subject.py"],"test_regression.py")
                original=replace(files["subject.py"],"body",task["original_body"])
                mutant=suite(files,original,"test_regression.py")
                checks["test"]["regression"]=reg
                checks["test"]["original_bug_detected"]=not mutant["passed"] and mutant["count"]>0
                if not reg["passed"] or not checks["test"]["original_bug_detected"]:
                    failures.append("regression must pass on patch and fail on original")
        checks["test"]["passed"]=not failures and checks["test"]["count"]>0
    except Exception as exc:
        failures.append({"exception":type(exc).__name__,"message":str(exc),"traceback":traceback.format_exc(limit=4)})
    checks["passed"]=checks["lint"]["passed"] and checks["test"]["passed"]
    checks["elapsed_seconds"]=time.perf_counter()-start
    return checks


if __name__=="__main__":
    task=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    workspace=Path(sys.argv[2])
    files={p:(workspace/p).read_text(encoding="utf-8") for p in task["files"]}
    answer_path=workspace/"answer.json"
    answer=json.loads(answer_path.read_text(encoding="utf-8")) if answer_path.exists() else None
    print(json.dumps(validate(task,files,answer),ensure_ascii=True))
